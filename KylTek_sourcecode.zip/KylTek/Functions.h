int toInt(std::wstring _line);
std::wstring toStr(int _value);
std::wstring toStr(long long _value);
std::wstring toStr(float _value);