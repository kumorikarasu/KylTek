// Yeah it'd be nice to have this. Having more member functions then the ones
// provided by DX's vector would help later on (like Length())

/*class Vector2
{
};*/